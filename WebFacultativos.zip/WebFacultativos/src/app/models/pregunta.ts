
export class Pregunta {
    IDPregunta: number;
    Descripcion: string;
    IDGrupo: number;
    IDArea: number;
    IDCuestionario: number;
    Orden: number;
}
