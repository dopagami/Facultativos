
export class Cuestionario {
    IDCuestionario: number;
    Descripcion: string;
    IDDepartamento: number;
    Areas: Array<any>;
    Grupos: Array<any>;
    Preguntas: Array<any>;
}
