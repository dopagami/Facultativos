export interface Facultativo {
    IDFacultativo: number;
    Nombre: string ;
    Apellido1: string;
    Apellido2: string;
    NumColegiado: string;
    Categoria: string;
    Puesto: string;
    Departamento: string;
    IDDepartamento: number;
    Centro: number;
    email: string;

  }
