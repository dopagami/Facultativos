
export class Grupo {
    IDGrupo: number;
    Descripcion: string;
    IDArea: number;
    IDCuestionario: number;
    Orden: number;
    Preguntas: Array<any>;
}
