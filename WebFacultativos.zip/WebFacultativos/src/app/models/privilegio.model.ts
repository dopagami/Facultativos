export interface Privilegio {
    IDPrivilegio: number | null;
    Valor: string;
    Descripcion: string;
}

