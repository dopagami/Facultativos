
export class Area {
    IDArea: number;
    Descripcion: string;
    IDCuestionario: number;
    Orden: number;
    Grupos: Array<any>;
    Preguntas: Array<any>;

}
